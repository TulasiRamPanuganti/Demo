import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  template: \`
    <h2>Weather Forecast</h2>
    <ul>
      <li *ngFor="let weather of weatherData">{{ weather }}</li>
    </ul>
  \`
})
export class AppComponent implements OnInit {
  weatherData: string[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<string[]>('http://localhost:5000/api/weather')
      .subscribe(data => this.weatherData = data);
  }
}