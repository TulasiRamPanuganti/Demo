# Simple .NET + Angular Project

- Backend: .NET 6 Web API
- Frontend: Angular for UI and data subscription

### API Endpoint:
- `GET /api/weather` returns a simple list of weather statuses

Make sure CORS is enabled on the backend for frontend access.